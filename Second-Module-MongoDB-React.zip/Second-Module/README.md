# Setup & Running

This project now has two parts that run separately: an Express + MongoDB API, and a Vite + React frontend.

## 1. Backend (API + MongoDB)

```bash
npm install
cp .env.example .env   # then edit MONGO_URI if needed
npm start               # or: npm run dev (auto-restarts on changes)
```

By default it connects to `mongodb://127.0.0.1:27017/taskmanager`. If you don't have MongoDB installed locally, either:
- Install MongoDB Community Server and run `mongod`, or
- Use a free [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) cluster and paste its connection string into `.env` as `MONGO_URI`.

The API runs at `http://localhost:3000` and no longer serves the old static `public/` folder — the frontend lives in `client/` now.

## 2. Frontend (React via Vite)

In a second terminal:

```bash
cd client
npm install
npm run dev
```

This opens the app at `http://localhost:5173`. Vite is configured to proxy `/api/...` requests to the backend on port 3000, so no CORS setup is needed in development.

To build a production bundle: `npm run build` inside `client/` (outputs to `client/dist/`).

## What changed from the original version

- **Database**: tasks used to live in a plain in-memory array (`models/taskModel.js`) that was wiped every time the server restarted. That's now a MongoDB collection via Mongoose (`models/Task.js`), so data persists across restarts.
- **Frontend**: the static `public/` HTML/CSS/JS has been replaced by a Vite + React app in `client/`, with the same features (add, edit in place, toggle complete, delete, search, filter by assignee/status).
- Routes and general MVC folder layout (`routes/`, `controllers/`, `models/`) are unchanged.

---

# Overview

As a software engineer I wanted to strengthen my JavaScript skills by creating a program that solves a problem: keeping track of tasks. I was curious how a program could store data let a user add and update items and keep that information organized while the program runs.

The software I made is a Task Manager command-line program. The software was built with JavaScript running on Node.js. When you run the software the software shows a menu that allows you to add a task view all tasks mark a task as complete and delete a task. Each task records its description and its completion status.

My goal in building the software was to become comfortable with core programming concepts in JavaScript such as variables, functions arrays, objects, loops and conditional logic. I wanted to practice reading user input updating a data structure based on that input and showing results back to the user clearly. I did this because I plan to build on these fundamentals, with JavaScript projects later. Getting the basics right helps a lot.

Youtube link: https://www.youtube.com/watch?v=OZWt46d1mL4

# Development Environment

I used Visual Studio Code as my IDE. I used Git/GitHub for version control.

I tested the program locally using Node.js. I tested each menu option manually by running the program and entering inputs to make sure tasks were added, listed completed and removed correctly.

I used JavaScript (Node.js) to build this program. I used the built-in readline module to read input, from the user. I used standard JavaScript arrays and objects to store and manage the list of tasks.

# Useful Websites

* [Node.js Official Documentation](https://nodejs.org/en/docs)
* [MDN Web Docs - JavaScript Guide](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide)
* [Node.js readline Documentation](https://nodejs.org/api/readline.html)
