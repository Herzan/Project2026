import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      // Forward /api requests to the Express backend during development
      '/api': {
        target: 'http://localhost:3000',
        changeOrigin: true
      }
    }
  }
});
