import { useState } from 'react';

export default function AddTaskForm({ onAdd, assignees }) {
  const [title, setTitle] = useState('');
  const [assignee, setAssignee] = useState('');

  function handleSubmit(e) {
    e.preventDefault();
    const trimmed = title.trim();
    if (!trimmed) return;
    onAdd({ title: trimmed, assignee: assignee.trim() });
    setTitle('');
    setAssignee('');
  }

  return (
    <form className="input-row" onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Enter a new task..."
        autoComplete="off"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        required
      />
      <input
        type="text"
        placeholder="Assign to (username)"
        autoComplete="off"
        list="assigneeOptions"
        value={assignee}
        onChange={(e) => setAssignee(e.target.value)}
      />
      <datalist id="assigneeOptions">
        {assignees.map((name) => (
          <option key={name} value={name} />
        ))}
      </datalist>
      <button type="submit" className="btn-add">Add</button>
    </form>
  );
}
