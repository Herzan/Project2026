import { useCallback, useEffect, useRef, useState } from 'react';
import AddTaskForm from './components/AddTaskForm.jsx';
import Toolbar from './components/Toolbar.jsx';
import TaskList from './components/TaskList.jsx';
import Toast from './components/Toast.jsx';
import * as api from './api.js';

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [assignees, setAssignees] = useState([]);

  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [assignee, setAssignee] = useState('');
  const [status, setStatus] = useState('all');

  const [toast, setToast] = useState({ message: '', isError: false });
  const toastTimer = useRef(null);

  const showToast = useCallback((message, isError = false) => {
    setToast({ message, isError });
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast({ message: '', isError: false }), 2200);
  }, []);

  const loadTasks = useCallback(async () => {
    try {
      const data = await api.getTasks({ search: debouncedSearch, assignee, status });
      setTasks(data);
    } catch (err) {
      showToast(err.message, true);
    }
  }, [debouncedSearch, assignee, status, showToast]);

  const loadAssignees = useCallback(async () => {
    try {
      setAssignees(await api.getAssignees());
    } catch {
      // non-critical
    }
  }, []);

  // Debounce the search box, same as the original 250ms delay
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search), 250);
    return () => clearTimeout(t);
  }, [search]);

  useEffect(() => {
    loadTasks();
  }, [loadTasks]);

  useEffect(() => {
    loadAssignees();
  }, [loadAssignees]);

  async function handleAdd({ title, assignee: who }) {
    try {
      await api.createTask({ title, assignee: who });
      showToast('Task added');
      await Promise.all([loadTasks(), loadAssignees()]);
    } catch (err) {
      showToast(err.message, true);
    }
  }

  async function handleToggle(id) {
    try {
      await api.toggleTask(id);
      loadTasks();
    } catch (err) {
      showToast(err.message, true);
    }
  }

  async function handleDelete(id) {
    try {
      await api.deleteTask(id);
      showToast('Task deleted');
      await Promise.all([loadTasks(), loadAssignees()]);
    } catch (err) {
      showToast(err.message, true);
    }
  }

  async function handleSave(id, updates) {
    try {
      await api.updateTask(id, updates);
      showToast('Task updated');
      await Promise.all([loadTasks(), loadAssignees()]);
    } catch (err) {
      showToast(err.message, true);
    }
  }

  const hasActiveFilters = Boolean(debouncedSearch || assignee || status !== 'all');

  return (
    <div className="container">
      <h1>✅ Task Manager</h1>

      <AddTaskForm onAdd={handleAdd} assignees={assignees} />

      <Toolbar
        search={search}
        onSearchChange={setSearch}
        assignee={assignee}
        onAssigneeChange={setAssignee}
        status={status}
        onStatusChange={setStatus}
        assignees={assignees}
      />

      <TaskList
        tasks={tasks}
        hasActiveFilters={hasActiveFilters}
        onToggle={handleToggle}
        onDelete={handleDelete}
        onSave={handleSave}
      />

      <Toast message={toast.message} isError={toast.isError} />
    </div>
  );
}
