const BASE = '/api/tasks';

async function handle(res) {
  if (!res.ok) {
    let message = 'Request failed';
    try {
      const body = await res.json();
      message = body.error || message;
    } catch {
      // ignore parse errors
    }
    throw new Error(message);
  }
  return res.json();
}

export function getTasks({ search, assignee, status } = {}) {
  const params = new URLSearchParams();
  if (search) params.set('search', search);
  if (assignee) params.set('assignee', assignee);
  if (status && status !== 'all') params.set('status', status);
  const qs = params.toString();
  return fetch(`${BASE}${qs ? `?${qs}` : ''}`).then(handle);
}

export function getAssignees() {
  return fetch(`${BASE}/assignees`).then(handle);
}

export function createTask({ title, assignee }) {
  return fetch(BASE, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, assignee })
  }).then(handle);
}

export function updateTask(id, { title, assignee }) {
  return fetch(`${BASE}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, assignee })
  }).then(handle);
}

export function toggleTask(id) {
  return fetch(`${BASE}/${id}/toggle`, { method: 'PUT' }).then(handle);
}

export function deleteTask(id) {
  return fetch(`${BASE}/${id}`, { method: 'DELETE' }).then(handle);
}
